import { Button } from "antd";

export default function Home() {
  return (
    <div className="flex items-center justify-center h-screen">
      <Button type="primary">Ant Design Button</Button>
    </div>
  );
}
