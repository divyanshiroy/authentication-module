import type { AppProps } from "next/app";
import "../styles/globals.css";
import "antd/dist/reset.css"; // Import Ant Design styles

export default function MyApp({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />;
}
