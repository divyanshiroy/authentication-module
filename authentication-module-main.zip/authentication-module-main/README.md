# authentication-module
Authentication module using ReactJS/NextJS with FastAPI, JWT, and MySQL
